package com.fis.bankapp.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.service.TransactionService;
import com.fis.bankapp.dao.TransactionDao;
import com.fis.bankapp.dao.TransactionDaoImpl;
/*
public class TransactionServiceImpl implements TransactionService {
	TransactionDao dao = new TransactionDaoImpl();
	
	@Override
	public String addDeposit(long dpAccNo, Transaction transaction) {
		return dao.addDeposit(dpAccNo, transaction);
	}
	
	@Override
	public String addWithdraw(long wdAccNo, Transaction transaction) {
		return dao.addWithdraw(wdAccNo, transaction);
	}

	@Override
	public String addTransactionNEFT(long transFromAcc, long neftAccNo, Transaction transaction) {
		return dao.addTransactionNEFT(transFromAcc, neftAccNo, transaction);
	}

	@Override
	public ArrayList<String> getTransForAccNo(Transaction transaction, long showTransAccNo) {
		return dao.getTransForAccNo(transaction, showTransAccNo);
	}

}*/



@Service
@Transactional
public class TransactionServiceImpl implements TransactionService{
	
	//This is the transaction service implementation class which implements the abstract methods.
	@Autowired
	TransactionDao dao;

	@Override
	public String addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		return dao.addTransaction(transaction);
	}

	@Override
	public List<Transaction> getTransactions(long AccNoFrom) {
		// TODO Auto-generated method stub
		return dao.getTransactions(AccNoFrom);
	}

	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return dao.getAllTransactions();
	}
}

