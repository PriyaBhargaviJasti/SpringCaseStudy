package com.fis.bankapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapp.exception.AccountNotFound;
import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.service.TransactionService;

//{
//"productId":111,
//"productName":"samsung",
//"productPrice":93000,
//"productCategory":"electronics"
//}
@RestController
@RequestMapping("/transactions")
public class TransactionController {
	@Autowired
	TransactionService service;

	@PostMapping("/addTransaction") // http://localhost:8080/transactions/addTransaction
	public String saveTransaction(@RequestBody Transaction transaction) {
		return service.addTransaction(transaction);
	}

	@GetMapping("/getTransactions/{transId}") // http://localhost:8080/transactions/getTransactions/888
	public List<Transaction> getTransactions(@PathVariable("tid") long AccNoFrom) {
		return service.getTransactions(AccNoFrom);
	}

	@GetMapping("/getAllTransactions") // http://localhost:8080/transactions/getAllTransactions
	public List<Transaction> getTransactions() {
		return service.getAllTransactions();
	}
	
	/*@PutMapping("/updateAccount") // http://localhost:8080/accounts/updateAccount
	public String updateAccount(@RequestBody Account account) {
		return service.updateAccount(account);
	}*/

	


}

