package com.fis.bankapp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
//import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "account_info")
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "accNo")
	private long accNo;
	private int custId;
	private String accType;
	private String branch;
	private String ifsc;
	private double balance;
	
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	public Account(int custId, long accNo, String accType, String branch, String ifsc, double balance) {
		super();
		this.custId = custId;
		this.accNo = accNo;
		this.accType = accType;
		this.branch = branch;
		this.ifsc = ifsc;
		this.balance = balance;
	}
	
	public Account() {
		// TODO Auto-generated constructor stub
	}
	
}